package com.example.homework.data;

import android.database.Cursor;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface PersonDAO {
    @Insert
    void insertPerson(Person person);
    @Update
    void updatePerson(Person person);
    @Query("DELETE  FROM person WHERE uid = :id")
    void deletePersonid(long id);
    @Delete
    void deletePerson(Person person);
    @Query("SELECT * FROM person")
    public Cursor listPeople();
}
