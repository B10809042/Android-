package com.example.homework.data;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "person")
public class Person {
    @PrimaryKey
    public long uid;
    @ColumnInfo(name = "password")
    public String password;
    public Person(long id, String pword){
        uid=id;
        password=pword;
    }
    public Person(){

    }
}
